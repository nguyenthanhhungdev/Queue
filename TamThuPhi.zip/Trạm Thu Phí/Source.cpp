﻿
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <string>
#include <conio.h>
using namespace std;

#define Max 10;

struct car
{
	string loaiXe;
	int soDangKy = 0;
};

struct InforOfCar
{
	car* xe;
	InforOfCar* next;
};

struct Queue
{
	InforOfCar* front;
	InforOfCar* rear;
	int cout;
};

int random(int minN, int maxN) {
	return minN + rand() % (maxN + 1 - minN);
}

car* thongtinxe()	
{
	car* xe = new car;
	int r = random(1, 4);
	switch (r) {
	case 1:
		xe->loaiXe = "xe Tai";
		break;
	case 2:
		xe->loaiXe = "xe Khach";
		break;
	case 3:
		xe->loaiXe = "xe Con";
		break;
	case 4:
		xe->loaiXe = "xe Container";
		break;
	}
	xe->soDangKy = random(1, 100);
	return xe;
}

InforOfCar* createNode(car* data)
{
	InforOfCar* p = new InforOfCar;
	if (p == NULL)
	{
		cout << "Day bo nho" << endl;
		exit(1);
	}

	else
	{
		p->xe = data;
		p->next = NULL;
	}
	return p;
}

void InIt(Queue& queue)
{
	queue.front = NULL;
	queue.rear = NULL;
	queue.cout = 0;
}


bool IsEmty(Queue queue)
{
	return queue.front == NULL;
}

bool IsFull(Queue queue)
{
	return queue.cout >= Max;
}

void EnQueue(Queue& queue, InforOfCar* p)
{
	if (IsEmty(queue))
	{
		queue.front = p;
	}
	else 
		queue.rear->next = p;
	queue.rear = p;
	queue.cout++;
}

void CarOut(Queue& queue)
{
	cout << "So luong xe ra: 1" << endl;
	cout << "Thong tin xe ra: " << endl;
	if (IsEmty(queue))
		exit(1);
	else
	{
		
		InforOfCar* p = queue.front;
		if (queue.front == queue.rear)
			queue.rear = queue.front = NULL;
		queue.front = p->next;
		cout << "Loai xe: " << p->xe->loaiXe << endl
			<< " So dang ky: " << p->xe->soDangKy << endl;
		delete p;
		queue.cout--;
	}
	cout << "=======================================" << endl;
}

void CarIn(Queue& queue)
{
	int r = 3;
	int i = 0;
	for (; i < r; i++)
	{
		if (IsFull(queue))
			break;
		EnQueue(queue, createNode(thongtinxe()));
	}
	cout << "So luong xe vao: " << i << endl;
}

void DisPlay(Queue queue)
{
	if (IsEmty(queue))
	{
		cout << "Khong co xe o hang doi" << endl;
		exit(1);
	}
	InforOfCar* p = queue.front;
	while (p != NULL)
	{
		cout << "Thong tin cac xe trong hang doi " << endl;
		cout << "Loai xe " << p->xe->loaiXe << endl << "So dang ky " << p->xe->soDangKy << endl;
		p = p->next;
	}
	cout << "=======================================" << endl;
}

int main()
{
	srand((int)time(NULL));
	Queue queue;
	InIt(queue);
	while (true)
	{
		CarIn(queue);
		cout << "So Luong Xe Trong Hang Doi " << queue.cout << endl;
		cout << "=======================================" << endl;
		if (IsEmty(queue))
			continue;
		DisPlay(queue);
		if (IsFull(queue))
		{
			while (!IsEmty(queue))
			{
				CarOut(queue);
			}
		}
		else
			CarOut(queue);
		cout << "So luong xe con lai trong hang doi: " << queue.cout << endl;
		cout << "=======================================" << endl;
		if (_kbhit())
			break;
	}
	return 0;
}